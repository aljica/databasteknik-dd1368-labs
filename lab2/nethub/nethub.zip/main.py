from tkinter import *
from search import Search

def main():
    root = Tk()
    nethub = Search(root)
    root.mainloop()

if __name__ == "__main__":
    main()
